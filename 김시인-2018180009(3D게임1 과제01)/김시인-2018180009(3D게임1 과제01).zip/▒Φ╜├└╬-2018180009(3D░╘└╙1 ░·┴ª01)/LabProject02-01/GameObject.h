#pragma once

#include "Mesh.h"
#include "Camera.h"

class CGameObject
{
public:
	CGameObject() { }
	virtual ~CGameObject();

public:
	bool						m_bActive = true;

	CMesh*						m_pMesh = NULL;
	XMFLOAT4X4A					m_xmf4x4World = Matrix4x4::Identity();

	BoundingOrientedBox			m_xmOOBB = BoundingOrientedBox();

	CGameObject*				m_pObjectCollided = NULL;
	DWORD						m_dwColor = RGB(255, 0, 0);

	XMFLOAT3A					m_xmf3MovingDirection = XMFLOAT3A(0.0f, 0.0f, 1.0f);
	float						m_fMovingSpeed = 0.0f;
	float						m_fMovingRange = 0.0f;

	XMFLOAT3A					m_xmf3RotationAxis = XMFLOAT3A(0.0f, 1.0f, 0.0f);
	float						m_fRotationSpeed = 0.0f;

public:
	void SetActive(bool bActive) { m_bActive = bActive; }
	void SetMesh(CMesh *pMesh) { m_pMesh = pMesh; if (pMesh) pMesh->AddRef(); }

	void SetColor(DWORD dwColor) { m_dwColor = dwColor; }

	void SetRotationTransform(XMFLOAT4X4A *pmxf4x4Transform);

	void SetPosition(float x, float y, float z);
	void SetPosition(XMFLOAT3A& xmf3Position);

	void SetMovingDirection(XMFLOAT3A& xmf3MovingDirection) { m_xmf3MovingDirection = Vector3::Normalize(xmf3MovingDirection); }
	void SetMovingSpeed(float fSpeed) { m_fMovingSpeed = fSpeed; }
	void SetMovingRange(float fRange) { m_fMovingRange = fRange; }

	void SetRotationAxis(XMFLOAT3A& xmf3RotationAxis) { m_xmf3RotationAxis = Vector3::Normalize(xmf3RotationAxis); }
	void SetRotationSpeed(float fSpeed) { m_fRotationSpeed = fSpeed; }

	void MoveStrafe(float fDistance = 1.0f);
	void MoveUp(float fDistance = 1.0f);
	void MoveForward(float fDistance = 1.0f);
	void Move(XMFLOAT3A& vDirection, float fSpeed);

	void Rotate(float fPitch = 10.0f, float fYaw = 10.0f, float fRoll = 10.0f);
	void Rotate(XMFLOAT3A& xmf3Axis, float fAngle);

	XMFLOAT3A GetPosition();
	XMFLOAT3A GetLook();
	XMFLOAT3A GetUp();
	XMFLOAT3A GetRight();

	void LookTo(XMFLOAT3A& xmf3LookTo, XMFLOAT3A& xmf3Up);
	void LookAt(XMFLOAT3A& xmf3LookAt, XMFLOAT3A& xmf3Up);

	void UpdateBoundingBox();

	void Render(HDC hDCFrameBuffer, XMFLOAT4X4A* pxmf4x4World, CMesh* pMesh);

	virtual void OnUpdateTransform() { }
	virtual void Animate(float fElapsedTime);
	virtual void Render(HDC hDCFrameBuffer, CCamera* pCamera);

	void GenerateRayForPicking(XMVECTOR& xmvPickPosition, XMMATRIX& xmmtxView, XMVECTOR& xmvPickRayOrigin, XMVECTOR& xmvPickRayDirection);
	int PickObjectByRayIntersection(XMVECTOR& xmPickPosition, XMMATRIX& xmmtxView, float* pfHitDistance);
};

class CExplosiveObject : public CGameObject
{
public:
	CExplosiveObject();
	virtual ~CExplosiveObject();

	bool						m_bBlowingUp = false;

	XMFLOAT4X4A					m_pxmf4x4Transforms[EXPLOSION_DEBRISES];

	float						m_fElapsedTimes = 0.0f;
	float						m_fDuration = 2.0f;
	float						m_fExplosionSpeed = 10.0f;
	float						m_fExplosionRotation = 720.0f;

	virtual void Animate(float fElapsedTime);
	virtual void Render(HDC hDCFrameBuffer, CCamera* pCamera);

public:
	static CMesh*				m_pExplosionMesh;
	static XMFLOAT3A				m_pxmf3SphereVectors[EXPLOSION_DEBRISES];

	static void PrepareExplosion();
};

class CWallsObject : public CGameObject
{
public:
	CWallsObject();
	virtual ~CWallsObject();

public:
	BoundingOrientedBox			m_xmOOBBPlayerMoveCheck = BoundingOrientedBox();
	XMFLOAT4A					m_pxmf4WallPlanes[6];

	virtual void Render(HDC hDCFrameBuffer, CCamera* pCamera);
};

class CBulletObject : public CGameObject
{
public:
	CBulletObject(float fEffectiveRange);
	virtual ~CBulletObject();

public:
	virtual void Animate(float fElapsedTime);

	float						m_fBulletEffectiveRange = 50.0f;
	float						m_fMovingDistance = 0.0f;
	float						m_fRotationAngle = 0.0f;
	XMFLOAT3A					m_xmf3FirePosition = XMFLOAT3A(0.0f, 0.0f, 1.0f);

	float						m_fElapsedTimeAfterFire = 0.0f;
	float						m_fLockingDelayTime = 0.3f;
	float						m_fLockingTime = 4.0f;
	CGameObject*				m_pLockedObject = NULL;

	void SetFirePosition(XMFLOAT3A xmf3FirePosition);
	void Reset();
};

class CAxisObject : public CGameObject
{
public:
	CAxisObject() { }
	virtual ~CAxisObject() { }

	virtual void Render(HDC hDCFrameBuffer, CCamera* pCamera);
};

class CRailWay : public CGameObject
{
public:
	CRailWay();

public:
	std::vector<XMFLOAT3A> points;
	std::vector<XMFLOAT3A> velocities;
	float lineDistance = 1.5f;

public:
	XMFLOAT3A CatmullRomSplines(const float& t, const int& startIndex, const int& endIndex);
	XMFLOAT3A CatmullRomSplinesVelocity(float t, int startIndex, int endIndex);
	size_t GetNumOfPoints();
	float GetDistanceBetweenTwoPoints(int index1, int index2);
	virtual void Render(HDC hDCFrameBuffer, CCamera* pCamera);

};

class CCart : public CGameObject
{
public:
	CCart(CRailWay*);

public:
	XMFLOAT3A position;
	XMFLOAT3A look;

	CRailWay* pMyRail;	//���� Ÿ���ִ� ����
	int railPoint;		//���� ����Ʈ ����
	float pointRatio;	// ��������
	float speed;		//�ӵ�

public:
	void OnUpdateTransform();
	int RailMove(float fElapsedTime);
	int RailMoveReverse(float fElapsedTime);
	virtual void Animate(float fElapsedTime, bool reverse = false);

};

class CEnemy : public CCart
{
public:
	CEnemy(CRailWay*);
	virtual ~CEnemy();

	bool						m_bBlowingUp = false;

	XMFLOAT4X4A					m_pxmf4x4Transforms[EXPLOSION_DEBRISES];

	float						m_fElapsedTimes = 0.0f;
	float						m_fDuration = 2.0f;
	float						m_fExplosionSpeed = 10.0f;
	float						m_fExplosionRotation = 720.0f;
	
	virtual void Animate(float fElapsedTime);
	virtual void Render(HDC hDCFrameBuffer, CCamera* pCamera);

public:
	static CMesh* m_pExplosionMesh;
	static XMFLOAT3A				m_pxmf3SphereVectors[EXPLOSION_DEBRISES];

	static void PrepareExplosion();
};

class CBullet : public CGameObject {
public:
	CBullet(CGameObject* target);
	~CBullet();

public:
	float speed = 0.5;
	CGameObject* target = NULL;

public:
	virtual void Animate(float fElapsedTime);

};
