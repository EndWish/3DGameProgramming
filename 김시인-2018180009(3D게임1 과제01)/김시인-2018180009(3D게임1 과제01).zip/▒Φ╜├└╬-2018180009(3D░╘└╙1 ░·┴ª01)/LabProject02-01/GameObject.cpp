#include "stdafx.h"
#include "GameObject.h"
#include "GraphicsPipeline.h"
/////////////////////////////////////////////////////////////////////////////////////////////////////
//
inline float RandF(float fMin, float fMax)
{
	return(fMin + ((float)rand() / (float)RAND_MAX) * (fMax - fMin));
}

XMVECTOR RandomUnitVectorOnSphere()
{
	XMVECTOR xmvOne = XMVectorSet(1.0f, 1.0f, 1.0f, 1.0f);
	XMVECTOR xmvZero = XMVectorZero();

	while (true)
	{
		XMVECTOR v = XMVectorSet(RandF(-1.0f, 1.0f), RandF(-1.0f, 1.0f), RandF(-1.0f, 1.0f), 0.0f);
		if (!XMVector3Greater(XMVector3LengthSq(v), xmvOne)) return(XMVector3Normalize(v));
	}
}


CGameObject::~CGameObject(void)
{
	if (m_pMesh) m_pMesh->Release();
}

void CGameObject::SetPosition(float x, float y, float z)
{
	m_xmf4x4World._41 = x;
	m_xmf4x4World._42 = y;
	m_xmf4x4World._43 = z;
}

void CGameObject::SetPosition(XMFLOAT3A& xmf3Position)
{
	m_xmf4x4World._41 = xmf3Position.x;
	m_xmf4x4World._42 = xmf3Position.y;
	m_xmf4x4World._43 = xmf3Position.z;
}

XMFLOAT3A CGameObject::GetPosition()
{
	return(XMFLOAT3A(m_xmf4x4World._41, m_xmf4x4World._42, m_xmf4x4World._43));
}

XMFLOAT3A CGameObject::GetLook()
{
	XMFLOAT3A xmf3LookAt(m_xmf4x4World._31, m_xmf4x4World._32, m_xmf4x4World._33);
	xmf3LookAt = Vector3::Normalize(xmf3LookAt);
	return(xmf3LookAt);
}

XMFLOAT3A CGameObject::GetUp()
{
	XMFLOAT3A xmf3Up(m_xmf4x4World._21, m_xmf4x4World._22, m_xmf4x4World._23);
	xmf3Up = Vector3::Normalize(xmf3Up);
	return(xmf3Up);
}

XMFLOAT3A CGameObject::GetRight()
{
	XMFLOAT3A xmf3Right(m_xmf4x4World._11, m_xmf4x4World._12, m_xmf4x4World._13);
	xmf3Right = Vector3::Normalize(xmf3Right);
	return(xmf3Right);
}

void CGameObject::SetRotationTransform(XMFLOAT4X4A* pmxf4x4Transform)
{
	m_xmf4x4World._11 = pmxf4x4Transform->_11; m_xmf4x4World._12 = pmxf4x4Transform->_12; m_xmf4x4World._13 = pmxf4x4Transform->_13;
	m_xmf4x4World._21 = pmxf4x4Transform->_21; m_xmf4x4World._22 = pmxf4x4Transform->_22; m_xmf4x4World._23 = pmxf4x4Transform->_23;
	m_xmf4x4World._31 = pmxf4x4Transform->_31; m_xmf4x4World._32 = pmxf4x4Transform->_32; m_xmf4x4World._33 = pmxf4x4Transform->_33;
}

void CGameObject::MoveStrafe(float fDistance)
{
	XMFLOAT3A xmf3Position = GetPosition();
	XMFLOAT3A xmf3Right = GetRight();
	xmf3Position = Vector3::Add(xmf3Position, Vector3::ScalarProduct(xmf3Right, fDistance));

	CGameObject::SetPosition(xmf3Position);
}

void CGameObject::MoveUp(float fDistance)
{
	XMFLOAT3A xmf3Position = GetPosition();
	XMFLOAT3A xmf3Up = GetUp();
	xmf3Position = Vector3::Add(xmf3Position, Vector3::ScalarProduct(xmf3Up, fDistance));

	CGameObject::SetPosition(xmf3Position);
}

void CGameObject::MoveForward(float fDistance)
{
	XMFLOAT3A xmf3Position = GetPosition();
	XMFLOAT3A xmf3LookAt = GetLook();
	xmf3Position = Vector3::Add(xmf3Position, Vector3::ScalarProduct(xmf3LookAt, fDistance));

	CGameObject::SetPosition(xmf3Position);
}

void CGameObject::Rotate(float fPitch, float fYaw, float fRoll)
{
	XMFLOAT4X4A mtxRotate = Matrix4x4::RotationYawPitchRoll(fPitch, fYaw, fRoll);
	m_xmf4x4World = Matrix4x4::Multiply(mtxRotate, m_xmf4x4World);
}

void CGameObject::Rotate(XMFLOAT3A& xmf3RotationAxis, float fAngle)
{
	XMFLOAT4X4A mtxRotate = Matrix4x4::RotationAxis(xmf3RotationAxis, fAngle);
	m_xmf4x4World = Matrix4x4::Multiply(mtxRotate, m_xmf4x4World);
}

void CGameObject::Move(XMFLOAT3A& vDirection, float fSpeed)
{
	SetPosition(m_xmf4x4World._41 + vDirection.x * fSpeed, m_xmf4x4World._42 + vDirection.y * fSpeed, m_xmf4x4World._43 + vDirection.z * fSpeed);
}

void CGameObject::LookTo(XMFLOAT3A& xmf3LookTo, XMFLOAT3A& xmf3Up)
{
	XMFLOAT4X4A xmf4x4View = Matrix4x4::LookToLH(GetPosition(), xmf3LookTo, xmf3Up);
	m_xmf4x4World._11 = xmf4x4View._11; m_xmf4x4World._12 = xmf4x4View._21; m_xmf4x4World._13 = xmf4x4View._31;
	m_xmf4x4World._21 = xmf4x4View._12; m_xmf4x4World._22 = xmf4x4View._22; m_xmf4x4World._23 = xmf4x4View._32;
	m_xmf4x4World._31 = xmf4x4View._13; m_xmf4x4World._32 = xmf4x4View._23; m_xmf4x4World._33 = xmf4x4View._33;
}

void CGameObject::LookAt(XMFLOAT3A& xmf3LookAt, XMFLOAT3A& xmf3Up)
{
	XMFLOAT4X4A xmf4x4View = Matrix4x4::LookAtLH(GetPosition(), xmf3LookAt, xmf3Up);
	m_xmf4x4World._11 = xmf4x4View._11; m_xmf4x4World._12 = xmf4x4View._21; m_xmf4x4World._13 = xmf4x4View._31;
	m_xmf4x4World._21 = xmf4x4View._12; m_xmf4x4World._22 = xmf4x4View._22; m_xmf4x4World._23 = xmf4x4View._32;
	m_xmf4x4World._31 = xmf4x4View._13; m_xmf4x4World._32 = xmf4x4View._23; m_xmf4x4World._33 = xmf4x4View._33;
}

void CGameObject::UpdateBoundingBox()
{
	if (m_pMesh)
	{
		m_pMesh->m_xmOOBB.Transform(m_xmOOBB, XMLoadFloat4x4(&m_xmf4x4World));
		XMStoreFloat4(&m_xmOOBB.Orientation, XMQuaternionNormalize(XMLoadFloat4(&m_xmOOBB.Orientation)));
	}
}

void CGameObject::Animate(float fElapsedTime)
{
	if (m_fRotationSpeed != 0.0f) Rotate(m_xmf3RotationAxis, m_fRotationSpeed * fElapsedTime);
	if (m_fMovingSpeed != 0.0f) Move(m_xmf3MovingDirection, m_fMovingSpeed * fElapsedTime);

	UpdateBoundingBox();
}

void CGameObject::Render(HDC hDCFrameBuffer, XMFLOAT4X4A* pxmf4x4World, CMesh* pMesh)
{
	if (pMesh)
	{
		CGraphicsPipeline::SetWorldTransform(pxmf4x4World);

		HPEN hPen = ::CreatePen(PS_SOLID, 0, m_dwColor);
		HPEN hOldPen = (HPEN)::SelectObject(hDCFrameBuffer, hPen);
		pMesh->Render(hDCFrameBuffer);
		::SelectObject(hDCFrameBuffer, hOldPen);
		::DeleteObject(hPen);
	}
}

void CGameObject::Render(HDC hDCFrameBuffer, CCamera* pCamera)
{
	if (pCamera->IsInFrustum(m_xmOOBB)) CGameObject::Render(hDCFrameBuffer, &m_xmf4x4World, m_pMesh);
}

void CGameObject::GenerateRayForPicking(XMVECTOR& xmvPickPosition, XMMATRIX& xmmtxView, XMVECTOR& xmvPickRayOrigin, XMVECTOR& xmvPickRayDirection)
{
	XMMATRIX xmmtxToModel = XMMatrixInverse(NULL, XMLoadFloat4x4(&m_xmf4x4World) * xmmtxView);

	XMFLOAT3A xmf3CameraOrigin(0.0f, 0.0f, 0.0f);
	xmvPickRayOrigin = XMVector3TransformCoord(XMLoadFloat3A(&xmf3CameraOrigin), xmmtxToModel);
	xmvPickRayDirection = XMVector3TransformCoord(xmvPickPosition, xmmtxToModel);
	xmvPickRayDirection = XMVector3Normalize(xmvPickRayDirection - xmvPickRayOrigin);
}

int CGameObject::PickObjectByRayIntersection(XMVECTOR& xmvPickPosition, XMMATRIX& xmmtxView, float* pfHitDistance)
{
	int nIntersected = 0;
	if (m_pMesh)
	{
		XMVECTOR xmvPickRayOrigin, xmvPickRayDirection;
		GenerateRayForPicking(xmvPickPosition, xmmtxView, xmvPickRayOrigin, xmvPickRayDirection);
		nIntersected = m_pMesh->CheckRayIntersection(xmvPickRayOrigin, xmvPickRayDirection, pfHitDistance);
	}
	return(nIntersected);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
CWallsObject::CWallsObject()
{
}

CWallsObject::~CWallsObject()
{
}

void CWallsObject::Render(HDC hDCFrameBuffer, CCamera* pCamera)
{
	CGameObject::Render(hDCFrameBuffer, &m_xmf4x4World, m_pMesh);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
XMFLOAT3A CExplosiveObject::m_pxmf3SphereVectors[EXPLOSION_DEBRISES];
CMesh* CExplosiveObject::m_pExplosionMesh = NULL;

CExplosiveObject::CExplosiveObject()
{
}

CExplosiveObject::~CExplosiveObject()
{
}

void CExplosiveObject::PrepareExplosion()
{
	for (int i = 0; i < EXPLOSION_DEBRISES; i++) XMStoreFloat3A(&m_pxmf3SphereVectors[i], ::RandomUnitVectorOnSphere());

	m_pExplosionMesh = new CCubeMesh(0.5f, 0.5f, 0.5f);
}

void CExplosiveObject::Animate(float fElapsedTime)
{
	if (m_bBlowingUp)
	{
		m_fElapsedTimes += fElapsedTime;
		if (m_fElapsedTimes <= m_fDuration)
		{
			XMFLOAT3A xmf3Position = GetPosition();
			for (int i = 0; i < EXPLOSION_DEBRISES; i++)
			{
				m_pxmf4x4Transforms[i] = Matrix4x4::Identity();
				m_pxmf4x4Transforms[i]._41 = xmf3Position.x + m_pxmf3SphereVectors[i].x * m_fExplosionSpeed * m_fElapsedTimes;
				m_pxmf4x4Transforms[i]._42 = xmf3Position.y + m_pxmf3SphereVectors[i].y * m_fExplosionSpeed * m_fElapsedTimes;
				m_pxmf4x4Transforms[i]._43 = xmf3Position.z + m_pxmf3SphereVectors[i].z * m_fExplosionSpeed * m_fElapsedTimes;
				m_pxmf4x4Transforms[i] = Matrix4x4::Multiply(Matrix4x4::RotationAxis(m_pxmf3SphereVectors[i], m_fExplosionRotation * m_fElapsedTimes), m_pxmf4x4Transforms[i]);
			}
		}
		else
		{
			m_bBlowingUp = false;
			m_fElapsedTimes = 0.0f;
		}
	}
	else
	{
		CGameObject::Animate(fElapsedTime);
	}
}

void CExplosiveObject::Render(HDC hDCFrameBuffer, CCamera* pCamera)
{
	if (m_bBlowingUp)
	{
		for (int i = 0; i < EXPLOSION_DEBRISES; i++)
		{
			CGameObject::Render(hDCFrameBuffer , &m_pxmf4x4Transforms[i], m_pExplosionMesh);
		}
	}
	else
	{
		CGameObject::Render(hDCFrameBuffer, pCamera);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
CBulletObject::CBulletObject(float fEffectiveRange)
{
	m_fBulletEffectiveRange = fEffectiveRange;
}

CBulletObject::~CBulletObject()
{
}

void CBulletObject::SetFirePosition(XMFLOAT3A xmf3FirePosition)
{
	m_xmf3FirePosition = xmf3FirePosition;
	SetPosition(xmf3FirePosition);
}

void CBulletObject::Reset()
{
	m_pLockedObject = NULL;
	m_fElapsedTimeAfterFire = 0;
	m_fMovingDistance = 0;
	m_fRotationAngle = 0.0f;

	m_bActive = false;
}

void CBulletObject::Animate(float fElapsedTime)
{
	m_fElapsedTimeAfterFire += fElapsedTime;

	float fDistance = m_fMovingSpeed * fElapsedTime;

	if ((m_fElapsedTimeAfterFire > m_fLockingDelayTime) && m_pLockedObject)
	{
		XMFLOAT3A xmf3Position = GetPosition();
		XMVECTOR xmvPosition = XMLoadFloat3A(&xmf3Position);

		XMFLOAT3A xmf3LockedObjectPosition = m_pLockedObject->GetPosition();
		XMVECTOR xmvLockedObjectPosition = XMLoadFloat3A(&xmf3LockedObjectPosition);
		XMVECTOR xmvToLockedObject = xmvLockedObjectPosition - xmvPosition;
		xmvToLockedObject = XMVector3Normalize(xmvToLockedObject);

		XMVECTOR xmvMovingDirection = XMLoadFloat3A(&m_xmf3MovingDirection);
		xmvMovingDirection = XMVector3Normalize(XMVectorLerp(xmvMovingDirection, xmvToLockedObject, 0.25f));
		XMStoreFloat3A(&m_xmf3MovingDirection, xmvMovingDirection);
	}
#ifdef _WITH_VECTOR_OPERATION
	XMFLOAT3A xmf3Position = GetPosition();

	m_fRotationAngle += m_fRotationSpeed * fElapsedTime;
	if (m_fRotationAngle > 360.0f) m_fRotationAngle = m_fRotationAngle - 360.0f;

	XMFLOAT4X4A mtxRotate1 = Matrix4x4::RotationYawPitchRoll(0.0f, m_fRotationAngle, 0.0f);

	XMFLOAT3A xmf3RotationAxis = Vector3::CrossProduct(m_xmf3RotationAxis, m_xmf3MovingDirection, true);
	float fDotProduct = Vector3::DotProduct(m_xmf3RotationAxis, m_xmf3MovingDirection);
	float fRotationAngle = ::IsEqual(fDotProduct, 1.0f) ? 0.0f : (float)XMConvertToDegrees(acos(fDotProduct));
	XMFLOAT4X4A mtxRotate2 = Matrix4x4::RotationAxis(xmf3RotationAxis, fRotationAngle);

	m_xmf4x4World = Matrix4x4::Multiply(mtxRotate1, mtxRotate2);

	XMFLOAT3A xmf3Movement = Vector3::ScalarProduct(m_xmf3MovingDirection, fDistance, false);
	xmf3Position = Vector3::Add(xmf3Position, xmf3Movement);
	SetPosition(xmf3Position);
#else
	XMFLOAT4X4A mtxRotate = Matrix4x4::RotationYawPitchRoll(0.0f, m_fRotationSpeed * fElapsedTime, 0.0f);
	m_xmf4x4World = Matrix4x4::Multiply(mtxRotate, m_xmf4x4World);
	XMFLOAT3A xmf3Movement = Vector3::ScalarProduct(m_xmf3MovingDirection, fDistance, false);
	XMFLOAT3A xmf3Position = GetPosition();
	xmf3Position = Vector3::Add(xmf3Position, xmf3Movement);
	SetPosition(xmf3Position);
	m_fMovingDistance += fDistance;
#endif

	UpdateBoundingBox();

	if ((m_fMovingDistance > m_fBulletEffectiveRange) || (m_fElapsedTimeAfterFire > m_fLockingTime)) Reset();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
void CAxisObject::Render(HDC hDCFrameBuffer, CCamera* pCamera)
{
	CGraphicsPipeline::SetWorldTransform(&m_xmf4x4World);

	m_pMesh->Render(hDCFrameBuffer);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
CRailWay::CRailWay() {

	//�� �ֱ�
	points.push_back(XMFLOAT3A(-20, 0, 30));
	points.push_back(XMFLOAT3A(-10, 0, 30));
	points.push_back(XMFLOAT3A(  0, 0, 30));
	points.push_back(XMFLOAT3A( 10,40, 30));
	points.push_back(XMFLOAT3A( 20,10, 25));	//5
	points.push_back(XMFLOAT3A( 27,-10, 10));
	points.push_back(XMFLOAT3A( 30,-5, 18));
	points.push_back(XMFLOAT3A( 35, 0, 7));
	points.push_back(XMFLOAT3A( 20, 10, 4));
	points.push_back(XMFLOAT3A( 20, 20, -8));	//10
	points.push_back(XMFLOAT3A( 35,-10, -12));
	points.push_back(XMFLOAT3A( 30, 12, -17));
	points.push_back(XMFLOAT3A( 22, 20, -20));
	points.push_back(XMFLOAT3A( 30, -9, -27));
	points.push_back(XMFLOAT3A( 22, 10, -35));	//15
	points.push_back(XMFLOAT3A( 17, 30, -20));
	points.push_back(XMFLOAT3A( 10, -20, -14));
	points.push_back(XMFLOAT3A( 5,  -20, -30));
	points.push_back(XMFLOAT3A( 5,  -10, -30));
	points.push_back(XMFLOAT3A( -7, -20, -25));
	points.push_back(XMFLOAT3A(-10, -10, 0));
	points.push_back(XMFLOAT3A(  0, 0, 10));
	points.push_back(XMFLOAT3A( 10, 5, 0));
	points.push_back(XMFLOAT3A(-10, 14, -12));
	points.push_back(XMFLOAT3A(-19, -3, -27));
	points.push_back(XMFLOAT3A(-25, 20, -34));
	points.push_back(XMFLOAT3A(-25, 10, -18));
	points.push_back(XMFLOAT3A(-28, 4, 0));
	points.push_back(XMFLOAT3A(-28, 0, 8));
	points.push_back(XMFLOAT3A(-20, 0, 8));
	points.push_back(XMFLOAT3A(-9, 0, 14));
	points.push_back(XMFLOAT3A(-27, 0, 23));
	points.push_back(XMFLOAT3A(-100, 0, 100));
	std::random_device rd;
	std::default_random_engine dre{ rd() };
	std::uniform_real_distribution<float> urd(-130.f, 130.f);
	for (int i = 0; i < 75; ++i) {
		points.push_back(XMFLOAT3A(urd(dre), urd(dre), urd(dre)));
	}

	size_t nPoints = points.size();
	for (int i = 0; i < nPoints; ++i) {
		int preIndex = (int)((i + nPoints - 1) % nPoints);
		int nextIndex = (i + 1) % nPoints;

		XMVECTOR newVelocity = (XMLoadFloat3A(&points[nextIndex]) - XMLoadFloat3A(&points[preIndex])) / 2;
		velocities.push_back(Vector3::XMVectorToFloat3(newVelocity));
	}

	//�� �����ϱ�
	std::vector<XMFLOAT3A> dividedPoints, dividedVelocities;
	dividedPoints.reserve(points.size());
	dividedVelocities.reserve(velocities.size());
	
	XMFLOAT3A curPoint;
	XMFLOAT3A curVelocity;

	float curDistance = 0;
	for (int startIndex = 0; startIndex < nPoints; ++startIndex) {	//�� ����Ʈ ���̸�

		int endIndex = (startIndex + 1) % nPoints;

		float wholeDistance = Vector3::Distance(points[startIndex], points[endIndex]);
		while (curDistance < wholeDistance)	//Ĺ�ַ� ���ö������� �����ؼ� �׸���.
		{
			float t = curDistance / wholeDistance;	// ���� ������ ���Ѵ�.

			curPoint = CatmullRomSplines(t, startIndex, endIndex);	// ������ ���Ѵ�.
			dividedPoints.push_back(curPoint);
			curVelocity = CatmullRomSplinesVelocity(t, startIndex, endIndex);
			dividedVelocities.push_back(curVelocity);

			curDistance += lineDistance;
		}
		curDistance -= wholeDistance;
	}

	dividedPoints.shrink_to_fit();
	dividedVelocities.shrink_to_fit();

	points = move(dividedPoints);
	velocities = move(dividedVelocities);
}

XMFLOAT3A CRailWay::CatmullRomSplines(const float& t, const int& startIndex, const int& endIndex) {
	const float t2 = t * t;
	const float t3 = t2 * t;
	
	XMVECTOR sPoint = XMLoadFloat3A(&points[startIndex]);
	XMVECTOR ePoint = XMLoadFloat3A(&points[endIndex]);
	XMVECTOR sVelocity = XMLoadFloat3A(&velocities[startIndex]);
	XMVECTOR eVelocity = XMLoadFloat3A(&velocities[endIndex]);

	return Vector3::XMVectorToFloat3( (2*t3-3*t2+1)*sPoint + (t3-2*t2+t)*sVelocity + (-2*t3+3*t2)*ePoint + (t3-t2)*eVelocity );
}

XMFLOAT3A CRailWay::CatmullRomSplinesVelocity(float t, int startIndex, int endIndex) {
	const float t2 = t * t;

	XMVECTOR sPoint = XMLoadFloat3A(&points[startIndex]);
	XMVECTOR ePoint = XMLoadFloat3A(&points[endIndex]);
	XMVECTOR sVelocity = XMLoadFloat3A(&velocities[startIndex]);
	XMVECTOR eVelocity = XMLoadFloat3A(&velocities[endIndex]);
	
	return Vector3::XMVectorToFloat3(6 * (t2 - t) * sPoint + (3 * t2 - 4 * t + 1) * sVelocity + 6 * (-t2 + t) * ePoint + (3 * t2 - 2 * t) * eVelocity);
}

size_t CRailWay::GetNumOfPoints() {
	return points.size();
}

float CRailWay::GetDistanceBetweenTwoPoints(int index1, int index2) {
	return Vector3::Distance(points[index1], points[index2]);
}

void CRailWay::Render(HDC hDCFrameBuffer, CCamera* pCamera) {
	//if (!pCamera->IsInFrustum(m_xmOOBB)) {
	//	return;
	//}

	CGraphicsPipeline::SetWorldTransform(&m_xmf4x4World);

	HPEN hPen1 = ::CreatePen(PS_SOLID, 1, RGB(0,255,0));
	HPEN hPen2 = ::CreatePen(PS_SOLID, 1, RGB(255,0,0));
	HPEN hOldPen = (HPEN)::SelectObject(hDCFrameBuffer, hPen1);

	int nPoints = points.size();
	XMFLOAT3A prePoint = points[nPoints - 1];
	XMFLOAT3A curPoint;

	for (int i = 0; i < nPoints; ++i) {
		if (i == 5) {
			::SelectObject(hDCFrameBuffer, hPen2);
		}

		curPoint = points[i];

		XMFLOAT3A preProjectPoint = CGraphicsPipeline::Project(prePoint);
		XMFLOAT3A curProjectPoint = CGraphicsPipeline::Project(curPoint);
		//�ϳ��� ���� ���ϰ��
		bool preProjectPointInside = (-1.0f <= preProjectPoint.x) && (preProjectPoint.x <= 1.0f) && (-1.0f <= preProjectPoint.y) && (preProjectPoint.y <= 1.0f) && (0.0f <= preProjectPoint.z) && (preProjectPoint.z <= 1.0f);
		bool curProjectPointInside = (-1.0f <= curProjectPoint.x) && (curProjectPoint.x <= 1.0f) && (-1.0f <= curProjectPoint.y) && (curProjectPoint.y <= 1.0f) && (0.0f <= curProjectPoint.z) && (curProjectPoint.z <= 1.0f);

		if (preProjectPointInside || curProjectPointInside) {
			Draw2DLine(hDCFrameBuffer, preProjectPoint, curProjectPoint);
		}
		prePoint = curPoint;
	}

	::SelectObject(hDCFrameBuffer, hOldPen);
	::DeleteObject(hPen1);
	::DeleteObject(hPen2);

}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
CCart::CCart(CRailWay* rail) : pMyRail(rail) {
	railPoint = 0;
	pointRatio = 0;
	speed = 5.0f;

	position = pMyRail->points[railPoint];
	look = Vector3::Normalize(pMyRail->velocities[railPoint]);
}

void CCart::OnUpdateTransform()
{
	XMFLOAT3A right = Vector3::CrossProduct(XMFLOAT3A(0, 1, 0), look);
	XMFLOAT3A up = Vector3::CrossProduct(look, right);

	m_xmf4x4World._11 = right.x; m_xmf4x4World._12 = right.y; m_xmf4x4World._13 = right.z;
	m_xmf4x4World._21 = up.x; m_xmf4x4World._22 = up.y; m_xmf4x4World._23 = up.z;
	m_xmf4x4World._31 = look.x; m_xmf4x4World._32 = look.y; m_xmf4x4World._33 = look.z;
	m_xmf4x4World._41 = position.x; m_xmf4x4World._42 = position.y; m_xmf4x4World._43 = position.z;

	m_xmf4x4World = Matrix4x4::Multiply(XMMatrixRotationRollPitchYaw(XMConvertToRadians(90.0f), 0.0f, 0.0f), m_xmf4x4World);
}

int CCart::RailMove(float fElapsedTime) {
	float moveDistance = speed * fElapsedTime;

	int nPoints = pMyRail->GetNumOfPoints();
	int nextPoint = (railPoint + 1) % nPoints;
	//���� ������ ���� ���̰Ÿ��� ���Ѵ�.
	float railDistance = pMyRail->GetDistanceBetweenTwoPoints(railPoint, nextPoint);
	// (�ӵ�/���ϰ� �Ÿ�)�� ���������� ���Ѵ�.
	pointRatio += (moveDistance / railDistance);
	// ���� ������ 1�̻��� �ɰ�� railPoint�� ����(��ȯ)��Ű�� �ʰ��и�ŭ ȯ���ؼ� �̿���Ų��.
	while (1 <= pointRatio) {
		pointRatio -= 1;
		railPoint = nextPoint;
		nextPoint = (railPoint + 1) % nPoints;

		float curRailDistance = pMyRail->GetDistanceBetweenTwoPoints(railPoint, nextPoint);
		pointRatio *= railDistance / curRailDistance;	//���� ����Ʈ������ �Ÿ��� �� �ٸ��� �ű⿡ ���� ȯ������
		railDistance = curRailDistance;

		if (railPoint == 0) {
			speed = 5.0f;
		}
	}

	return nextPoint;
}

int CCart::RailMoveReverse(float fElapsedTime) {
	float moveDistance = speed * fElapsedTime;

	int nPoints = pMyRail->GetNumOfPoints();
	int nextPoint = railPoint - 1 < 0 ? nPoints - 1 : railPoint - 1;
	//���� ������ ���� ���̰Ÿ��� ���Ѵ�.
	float railDistance = pMyRail->GetDistanceBetweenTwoPoints(railPoint, nextPoint);
	// (�ӵ�/���ϰ� �Ÿ�)�� ���������� ���Ѵ�.
	pointRatio -= (moveDistance / railDistance);
	// ���� ������ 1�̻��� �ɰ�� railPoint�� ����(��ȯ)��Ű�� �ʰ��и�ŭ ȯ���ؼ� �̿���Ų��.
	while (pointRatio <= 0) {
		pointRatio += 1;
		railPoint = nextPoint;
		nextPoint = railPoint - 1 < 0 ? nPoints - 1 : railPoint - 1;

		float curRailDistance = pMyRail->GetDistanceBetweenTwoPoints(railPoint, nextPoint);
		pointRatio *= railDistance / curRailDistance;	//���� ����Ʈ������ �Ÿ��� �� �ٸ��� �ű⿡ ���� ȯ������
		railDistance = curRailDistance;

		if (railPoint == 0) {
			speed = 5.0f;
		}
	}

	return nextPoint;
}

void CCart::Animate(float fElapsedTime, bool reverse) {
	int nextPoint;
	if (reverse) {
		nextPoint = RailMoveReverse(fElapsedTime);
	}
	else {
		nextPoint = RailMove(fElapsedTime);
	}

	//��ġ�� ������ �ֽ�ȭ�Ѵ�.
	XMFLOAT3A velocity;
	if (reverse) {
		position = Vector3::XMVectorToFloat3(XMLoadFloat3A(&pMyRail->points[nextPoint]) * (1.f - pointRatio) + XMLoadFloat3A(&pMyRail->points[railPoint]) * pointRatio);
		velocity = Vector3::XMVectorToFloat3(-XMLoadFloat3A(&pMyRail->velocities[nextPoint]) * (1.f - pointRatio) - XMLoadFloat3A(&pMyRail->velocities[railPoint]) * pointRatio);
	}
	else {
		position = Vector3::XMVectorToFloat3(XMLoadFloat3A(&pMyRail->points[railPoint]) * (1.f - pointRatio) + XMLoadFloat3A(&pMyRail->points[nextPoint]) * pointRatio);
		velocity = Vector3::XMVectorToFloat3(XMLoadFloat3A(&pMyRail->velocities[railPoint]) * (1.f - pointRatio) + XMLoadFloat3A(&pMyRail->velocities[nextPoint]) * pointRatio);
	}
	look = Vector3::Normalize(velocity);

	//�ѷ��ڽ����� �������� ó���Ѵ�.
	if (velocity.y > 0) {
		speed = max(5.f + 10.f, speed * (1 - 0.8f * fElapsedTime));
	}
	else if (velocity.y < 0) {
		speed = min(500.f, speed * (1.f + 1.f * fElapsedTime));
	}

	//
	OnUpdateTransform();
	UpdateBoundingBox();

}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
XMFLOAT3A CEnemy::m_pxmf3SphereVectors[EXPLOSION_DEBRISES];
CMesh* CEnemy::m_pExplosionMesh = NULL;

CEnemy::CEnemy(CRailWay* rail) : CCart(rail) {
	railPoint = rand() % rail->GetNumOfPoints();
}

CEnemy::~CEnemy(){
}

void CEnemy::PrepareExplosion()
{
	for (int i = 0; i < EXPLOSION_DEBRISES; i++) XMStoreFloat3A(&m_pxmf3SphereVectors[i], ::RandomUnitVectorOnSphere());

	m_pExplosionMesh = new CCubeMesh(0.5f, 0.5f, 0.5f);
}

void CEnemy::Animate(float fElapsedTime)
{
	if (m_bBlowingUp)
	{
		m_fElapsedTimes += fElapsedTime;
		if (m_fElapsedTimes <= m_fDuration)
		{
			XMFLOAT3A xmf3Position = GetPosition();
			for (int i = 0; i < EXPLOSION_DEBRISES; i++)
			{
				m_pxmf4x4Transforms[i] = Matrix4x4::Identity();
				m_pxmf4x4Transforms[i]._41 = xmf3Position.x + m_pxmf3SphereVectors[i].x * m_fExplosionSpeed * m_fElapsedTimes;
				m_pxmf4x4Transforms[i]._42 = xmf3Position.y + m_pxmf3SphereVectors[i].y * m_fExplosionSpeed * m_fElapsedTimes;
				m_pxmf4x4Transforms[i]._43 = xmf3Position.z + m_pxmf3SphereVectors[i].z * m_fExplosionSpeed * m_fElapsedTimes;
				m_pxmf4x4Transforms[i] = Matrix4x4::Multiply(Matrix4x4::RotationAxis(m_pxmf3SphereVectors[i], m_fExplosionRotation * m_fElapsedTimes), m_pxmf4x4Transforms[i]);
			}
		}
		else
		{
			//�����Ǳ�
			m_bActive = false;
			m_bBlowingUp = false;
			m_fElapsedTimes = 0.0f;
		}
	}
	else
	{
		CCart::Animate(fElapsedTime, true);
	}
}

void CEnemy::Render(HDC hDCFrameBuffer, CCamera* pCamera)
{
	if (m_bBlowingUp)
	{
		for (int i = 0; i < EXPLOSION_DEBRISES; i++)
		{
			CGameObject::Render(hDCFrameBuffer, &m_pxmf4x4Transforms[i], m_pExplosionMesh);
		}
	}
	else
	{
		CCart::Render(hDCFrameBuffer, pCamera);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//
CBullet::CBullet(CGameObject* target) {
	this->target = target;
}

CBullet::~CBullet() {

}

void CBullet::Animate(float fElapsedTime) {
	if (target == NULL) {
		m_bActive = false;
		return;
	}

	if (speed < 10.0) {
		speed += speed * 5.0f * fElapsedTime;
	}
	
	Move(Vector3::Subtract(target->GetPosition(), GetPosition()), speed * fElapsedTime);

	UpdateBoundingBox();
}
