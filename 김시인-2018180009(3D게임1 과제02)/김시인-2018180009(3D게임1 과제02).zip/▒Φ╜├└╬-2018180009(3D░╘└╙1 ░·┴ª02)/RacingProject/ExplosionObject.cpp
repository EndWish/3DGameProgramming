#include "stdafx.h"
#include "Shader.h"
#include "ExplosionObject.h"

//static
XMFLOAT3A CExplosionObject::m_explosionCubeVectors[nExplosionCube];
void CExplosionObject::PrepareExplosion() {
	for (int i = 0; i < nExplosionCube; i++)
		m_explosionCubeVectors[i] = Vector3::RandomUnitVectorOnSphere();
}

// ������
CExplosionObject::CExplosionObject() 
{
	for (int i = 0; i < nExplosionCube; ++i) {
		m_explosionCubeWorldTransfroms[i] = Matrix4x4::Identity();
	}
}

CExplosionObject::~CExplosionObject() {

}

void CExplosionObject::Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent) {
	if (m_active) {
		m_fElapsedTimes += fTimeElapsed;
		if (m_fElapsedTimes <= m_fDuration) {
			XMFLOAT3A xmf3Position = GetPosition();
			for (int i = 0; i < nExplosionCube; i++) {
				m_explosionCubeWorldTransfroms[i] = Matrix4x4::Identity();
				m_explosionCubeWorldTransfroms[i]._41 = xmf3Position.x + m_explosionCubeVectors[i].x * m_fExplosionSpeed * m_fElapsedTimes;
				m_explosionCubeWorldTransfroms[i]._42 = xmf3Position.y + m_explosionCubeVectors[i].y * m_fExplosionSpeed * m_fElapsedTimes;
				m_explosionCubeWorldTransfroms[i]._43 = xmf3Position.z + m_explosionCubeVectors[i].z * m_fExplosionSpeed * m_fElapsedTimes;
				m_explosionCubeWorldTransfroms[i] = Matrix4x4::Multiply(Matrix4x4::RotationAxis(m_explosionCubeVectors[i], m_fExplosionRotation * m_fElapsedTimes), m_explosionCubeWorldTransfroms[i]);
			}
		}
		else {
			m_active = false;
			m_fElapsedTimes = 0.0f;
		}
	}
}

void CExplosionObject::Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera) 
{
	if (m_active) {
		OnPrepareRender();

		if (m_pShader && m_pMesh) {
			m_pShader->Render(pd3dCommandList, pCamera);
			for (int i = 0; i < nExplosionCube; ++i) {
				m_pShader->UpdateShaderVariable(pd3dCommandList, &m_explosionCubeWorldTransfroms[i]);
				m_pMesh->Render(pd3dCommandList);
			}
		}

		//���� ��ü�� �޽��� ����Ǿ� ������ ����Ʈ�� ������ �Ѵ�.
		if (m_pMesh)

			if (m_pSibling) m_pSibling->Render(pd3dCommandList, pCamera);
		if (m_pChild) m_pChild->Render(pd3dCommandList, pCamera);
	}
}

void CExplosionObject::SetActive(bool active, XMFLOAT3A position) 
{
	m_active = active;
	if (m_active) {
		m_fElapsedTimes = 0.0f;

		SetPosition(position);
		//for (int i = 0; i < nExplosionCube; ++i) {
		//	//m_explosionCubeWorldTransfroms[i] = Matrix4x4::Identity();	// �����ڿ��� �̹� �߰�, �����Ǹ� �ٲ���
		//	XMFLOAT3A xmf3Position = GetPosition();
		//	m_explosionCubeWorldTransfroms[i]._41 = xmf3Position.x + m_explosionCubeVectors[i].x;
		//	m_explosionCubeWorldTransfroms[i]._42 = xmf3Position.y + m_explosionCubeVectors[i].y;
		//	m_explosionCubeWorldTransfroms[i]._43 = xmf3Position.z + m_explosionCubeVectors[i].z;
		//}
	}
}