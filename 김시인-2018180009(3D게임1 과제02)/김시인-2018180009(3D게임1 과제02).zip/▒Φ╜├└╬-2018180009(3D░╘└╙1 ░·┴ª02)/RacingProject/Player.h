#pragma once
#include "RailObject.h"

class CPlayer : public CGameObject {
public:
	CPlayer();
	CPlayer(CRailObject* rail);
	virtual ~CPlayer();

protected:
	CRailConnector m_railConnecter;
	CCamera m_camera;

public:
	void SetRail(CRailObject* rail) { m_railConnecter.SetRail(rail); }
	int GetPoint() { return m_railConnecter.GetPoint(); }
	CCamera* GetpCamera() { return &m_camera; }
	void LaneChange(int addLine);
	void SetSpeed(float speed) { m_railConnecter.SetSpeed(speed); }
	float GetSpeed() { return m_railConnecter.GetSpeed(); }
	
public:
	virtual void Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent);
	virtual void UpdateTransform(XMFLOAT4X4A* pxmf4x4Parent);
};

