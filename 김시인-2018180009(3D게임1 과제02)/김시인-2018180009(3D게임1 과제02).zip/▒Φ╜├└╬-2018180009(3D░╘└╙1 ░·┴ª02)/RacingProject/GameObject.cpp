#include "stdafx.h"
#include "Shader.h"	//
#include "GameObject.h"

///////////////////////////////////////////////////////////////////////////////
/// 

//������
CGameObject::CGameObject() 
{
	m_xmf4x4Transform = Matrix4x4::Identity();
	XMStoreFloat4x4A(&m_xmf4x4World, XMMatrixIdentity());
}
//�Ҹ���
CGameObject::~CGameObject() 
{
	if (m_pMesh) m_pMesh->Release();
	if (m_pShader) {
		m_pShader->ReleaseShaderVariables();
		m_pShader->Release();
	}
}
//�� ���̴�
void CGameObject::SetShader(CShader* pShader) 
{
	if (m_pShader) m_pShader->Release();
	m_pShader = pShader;
	if (m_pShader) m_pShader->AddRef();

	if (m_pSibling) m_pSibling->SetShader(pShader);
	if (m_pChild) m_pChild->SetShader(pShader);
}
//�� �޽�
void CGameObject::SetMesh(CMesh* pMesh) 
{
	if (m_pMesh) m_pMesh->Release();
	m_pMesh = pMesh;
	if (m_pMesh) m_pMesh->AddRef();
}
//�� ���ϵ�
void CGameObject::SetChild(CGameObject* pChild, bool bReferenceUpdate) 
{
	if (pChild) {
		pChild->m_pParent = this;
		if (bReferenceUpdate) pChild->AddRef();
	}
	if (m_pChild) {
		if (pChild) pChild->m_pSibling = m_pChild->m_pSibling;
		m_pChild->m_pSibling = pChild;
	}
	else {
		m_pChild = pChild;
	}
}
//���� ���۸� ���� ���ε� ���۸� �Ҹ��Ų��.
void CGameObject::ReleaseUploadBuffers() 
{
	//���� ���۸� ���� ���ε� ���۸� �Ҹ��Ų��. 
	if (m_pMesh) m_pMesh->ReleaseUploadBuffers();
}
//�ִϸ��̼�
void CGameObject::Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent)
{
	if (m_pSibling) m_pSibling->Animate(fTimeElapsed, pxmf4x4Parent);
	if (m_pChild) m_pChild->Animate(fTimeElapsed, &m_xmf4x4World);
}
//������ �غ�
void CGameObject::OnPrepareRender() 
{
}
//�������ϱ�
void CGameObject::Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera) 
{
	OnPrepareRender();

	if (m_pShader) {
		//���� ��ü�� ���� ��ȯ ����� ���̴��� ��� ���۷� ����(����)�Ѵ�. 
		m_pShader->UpdateShaderVariable(pd3dCommandList, &m_xmf4x4World);
		m_pShader->Render(pd3dCommandList, pCamera);
	}

	//���� ��ü�� �޽��� ����Ǿ� ������ �޽��� �������Ѵ�. 
	if (m_pMesh) m_pMesh->Render(pd3dCommandList);

	if (m_pSibling) m_pSibling->Render(pd3dCommandList, pCamera);
	if (m_pChild) m_pChild->Render(pd3dCommandList, pCamera);
}
//ȸ��(Cubeȸ����Ű�� ���� ����)
void CGameObject::Rotate(XMFLOAT3A* pxmf3Axis, float fAngle) 
{
	XMMATRIX mtxRotate = XMMatrixRotationAxis(XMLoadFloat3A(pxmf3Axis), XMConvertToRadians(fAngle));
	m_xmf4x4World = Matrix4x4::Multiply(mtxRotate, m_xmf4x4World);
}
//Transfrom ������Ʈ
void CGameObject::UpdateTransform(XMFLOAT4X4A* pxmf4x4Parent) {
	m_xmf4x4World = (pxmf4x4Parent) ? Matrix4x4::Multiply(m_xmf4x4Transform, *pxmf4x4Parent) : m_xmf4x4Transform;

	if (m_pSibling) m_pSibling->UpdateTransform(pxmf4x4Parent);
	if (m_pChild) m_pChild->UpdateTransform(&m_xmf4x4World);
}
//BoundingBox ������Ʈ
void CGameObject::UpdateBoundingBox() {
	if (m_pMesh) {
		m_pMesh->m_xmOOBB.Transform(m_xmOOBB, XMLoadFloat4x4A(&m_xmf4x4World));
		XMStoreFloat4(&m_xmOOBB.Orientation, XMQuaternionNormalize(XMLoadFloat4(&m_xmOOBB.Orientation)));
	}

	if (m_pSibling) m_pSibling->UpdateBoundingBox();
	if (m_pChild) m_pChild->UpdateBoundingBox();
}
//�浿üũ
bool CGameObject::CheckCollision(CGameObject& rhs)
{
	if (m_pMesh) {
		// �񱳴��� �浵üũ Ȯ��
		if (rhs.m_pMesh && m_xmOOBB.Intersects(rhs.m_xmOOBB)) {
			return true;
		}
		// �񱳴���� ������ �ڽ��� ������ ���� ��� ���� ����.
		if (rhs.m_pSibling && CheckCollision(*rhs.m_pSibling)) {
			return true;
		}
		if (rhs.m_pChild && CheckCollision(*rhs.m_pChild)) {
			return true;
		}
	}

	// �� ������ �ڽ��̶� �񱳴��� �浹üũ�ϴ��� Ȯ��
	if (m_pSibling && m_pSibling->CheckCollision(rhs)) {
		return true;
	}
	if (m_pChild && m_pChild->CheckCollision(rhs)) {
		return true;
	}

	return false;
}
// �� ��ġ
void CGameObject::SetPosition(float x, float y, float z) {
	m_xmf4x4Transform._41 = x;
	m_xmf4x4Transform._42 = y;
	m_xmf4x4Transform._43 = z;

	UpdateTransform(NULL);
}
// �� ��ġ
void CGameObject::SetPosition(XMFLOAT3A xmf3Position) {
	SetPosition(xmf3Position.x, xmf3Position.y, xmf3Position.z);
}

CMeshLoadInfo* CGameObject::LoadMeshInfoFromFile(std::ifstream& file) {
	std::string token;

	int nPositions = 0, nColors = 0, nNormals = 0, nIndices = 0, nSubMeshes = 0, nSubIndices = 0;

	CMeshLoadInfo* pMeshInfo = new CMeshLoadInfo();

	file >> pMeshInfo->m_nVertices >> pMeshInfo->m_name;

	for (; ; ) {
		file >> token;

		if (token == "<Bounds>:") {
			file >> pMeshInfo->m_xmf3AABBCenter;
			file >> pMeshInfo->m_xmf3AABBExtents;
		}
		else if (token == "<Positions>:") {
			file >> nPositions;
			if (nPositions > 0) {
				pMeshInfo->m_nType |= VERTEXT_POSITION;
				pMeshInfo->m_pxmf3Positions = new XMFLOAT3A[nPositions];
				for(int i = 0; i < nPositions; ++i)
					file >> pMeshInfo->m_pxmf3Positions[i];
			}
		}
		else if (token == "<Colors>:") {
			file >> nColors;
			if (nColors > 0) {
				pMeshInfo->m_nType |= VERTEXT_COLOR;
				pMeshInfo->m_pxmf4Colors = new XMFLOAT4A[nColors];
				for (int i = 0; i < nColors; ++i)
					file >> pMeshInfo->m_pxmf4Colors[i];
			}
		}
		else if (token == "<Normals>:") {
			file >> nNormals;
			if (nNormals > 0) {
				pMeshInfo->m_nType |= VERTEXT_NORMAL;
				pMeshInfo->m_pxmf3Normals = new XMFLOAT3A[nNormals];
				for (int i = 0; i < nNormals; ++i)
					file >> pMeshInfo->m_pxmf3Normals[i];
			}
		}
		else if (token == "<Indices>:") {
			file >> nIndices;
			if (nIndices > 0) {
				pMeshInfo->m_pnIndices = new UINT[nIndices];
				for (int i = 0; i < nIndices; ++i)
					file >> pMeshInfo->m_pnIndices[i];
			}
		}
		else if (token == "<SubMeshes>:") {
			file >> pMeshInfo->m_nSubMeshes;
			if (pMeshInfo->m_nSubMeshes > 0) {
				pMeshInfo->m_pnSubSetIndices = new int[pMeshInfo->m_nSubMeshes];
				pMeshInfo->m_ppnSubSetIndices = new UINT* [pMeshInfo->m_nSubMeshes];
				for (int i = 0; i < pMeshInfo->m_nSubMeshes; i++) {
					file >> token;
					if (token == "<SubMesh>:") {
						int nIndex;
						file >> nIndex;
						file >> pMeshInfo->m_pnSubSetIndices[i];
						if (pMeshInfo->m_pnSubSetIndices[i] > 0) {
							pMeshInfo->m_ppnSubSetIndices[i] = new UINT[pMeshInfo->m_pnSubSetIndices[i]];
							for (int j = 0; j < pMeshInfo->m_pnSubSetIndices[i]; ++j)
								file >> pMeshInfo->m_ppnSubSetIndices[i][j];
						}

					}
				}
			}
		}
		else if (token == "</Mesh>") {
			break;
		}
	}
	return(pMeshInfo);

}

CGameObject* CGameObject::LoadFrameHierarchyFromFile(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList, std::ifstream& file)
{
	std::string token;

	int nFrame = 0;

	CGameObject* pGameObject = NULL;

	while (true) {
		file >> token;

		if (token == "<Frame>:") {	// ���ο� �������� ����
			pGameObject = new CGameObject();
			file >> nFrame;	// ������ �ѹ�, ���° ������ ����
			file >> pGameObject->m_frameName;
		}
		else if (token == "<Transform>:") {
			XMFLOAT3A xmf3Position, xmf3Rotation, xmf3Scale;
			XMFLOAT4A xmf4Rotation;
			file >> xmf3Position >> xmf3Rotation >> xmf3Scale >> xmf4Rotation;
		}
		else if (token == "<TransformMatrix>:") {
			file >> pGameObject->m_xmf4x4Transform;	// ����
		}
		else if (token == "<Mesh>:") {
			CMeshLoadInfo* pMeshInfo = pGameObject->LoadMeshInfoFromFile(file);
			if (pMeshInfo) {
				CMeshFromFile* pMesh = new CMeshFromFile(pd3dDevice, pd3dCommandList, pMeshInfo);
				if (pMesh) pGameObject->SetMesh(pMesh);
				delete pMeshInfo;
			}
		}
		else if (token == "<Materials>:") {
			std::string buffer;
			while (file >> buffer) {
				if (buffer == "</Materials>")
					break;
			}
		}
		else if (token == "<Children>:") {
			int nChilds;
			file >> nChilds;
			if (nChilds > 0) {
				for (int i = 0; i < nChilds; i++) {
					CGameObject* pChild = CGameObject::LoadFrameHierarchyFromFile(pd3dDevice, pd3dCommandList, file);
					if (pChild) pGameObject->SetChild(pChild);
				}
			}
		}
		else if (token == "</Frame>") {
			break;
		}
	}
	return(pGameObject);

}

CGameObject* CGameObject::LoadGeometryFromFile(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList, std::string fileName)
{
	std::ifstream file{ fileName };

	CGameObject* pGameObject = NULL;
	std::string token;

	while (true) {
		file >> token;

		if (token == "<Hierarchy>:") {
			pGameObject = CGameObject::LoadFrameHierarchyFromFile(pd3dDevice, pd3dCommandList, file);
		}
		else if (token == "</Hierarchy>") {
			break;
		}
	}

	return pGameObject;
}


///////////////////////////////////////////////////////////////////////////////
/// 
CRotatingObject::CRotatingObject() 
{
	m_xmf3RotationAxis = XMFLOAT3A(0.0f, 1.0f, 0.0f);
	m_fRotationSpeed = 90.0f;
}

CRotatingObject::~CRotatingObject() 
{
	
}

void CRotatingObject::Animate(float fTimeElapsed) 
{
	CGameObject::Rotate(&m_xmf3RotationAxis, m_fRotationSpeed * fTimeElapsed);
}

