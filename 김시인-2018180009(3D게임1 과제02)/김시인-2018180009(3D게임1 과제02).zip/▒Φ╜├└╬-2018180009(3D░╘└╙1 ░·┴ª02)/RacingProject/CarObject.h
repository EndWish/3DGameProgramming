#pragma once
#include "RailObject.h"

class CCarObject : public CGameObject {

public:
	CCarObject();
	CCarObject(CRailObject* rail);
	virtual ~CCarObject();

protected:
	CRailConnector m_railConnecter;
	bool m_active = false;

public:
	void SetRail(CRailObject* rail) { m_railConnecter.SetRail(rail); }
	void SetActive(bool active, int line = 0, int point = 0);
	bool IsActive() { return m_active; }

public:
	virtual void Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent, int playerPoint);
	virtual void Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera);
	virtual void UpdateTransform(XMFLOAT4X4A* pxmf4x4Parent);
};

