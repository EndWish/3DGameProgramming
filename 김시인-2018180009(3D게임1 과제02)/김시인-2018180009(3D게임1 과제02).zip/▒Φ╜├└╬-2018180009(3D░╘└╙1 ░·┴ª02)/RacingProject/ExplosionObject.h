#pragma once
#include "GameObject.h"
class CExplosionObject : public CGameObject {
public:
	CExplosionObject();
	~CExplosionObject();

public:
	static void PrepareExplosion();

	virtual void Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent);
	virtual void Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera);

	void SetActive(bool active, XMFLOAT3A position);

protected:
	static const int nExplosionCube = 100;
	static XMFLOAT3A m_explosionCubeVectors[nExplosionCube];


	bool m_active = false;
	XMFLOAT4X4A m_explosionCubeWorldTransfroms[nExplosionCube];

	float m_fElapsedTimes = 0.0f;
	float m_fDuration = 2.0f;
	float m_fExplosionSpeed = 10.0f;
	float m_fExplosionRotation = 720.0f;

};

