#include "stdafx.h"
#include "Player.h"

CPlayer::CPlayer() {
	m_camera.SetViewport(0, 0, FRAME_BUFFER_WIDTH, FRAME_BUFFER_HEIGHT, 0.0f, 1.0f);
	m_camera.SetScissorRect(0, 0, FRAME_BUFFER_WIDTH, FRAME_BUFFER_HEIGHT);
	m_camera.GenerateProjectionMatrix(1.0f, 500.0f, float(FRAME_BUFFER_WIDTH) / float(FRAME_BUFFER_HEIGHT), 90.0f);
	m_camera.GenerateViewMatrix(Vector3::TransformCoord(XMFLOAT3A(0, 5, -5), m_xmf4x4World), Vector3::Add( XMFLOAT3A(m_xmf4x4World.m[3]), XMFLOAT3A(0,2,0)), XMFLOAT3A(m_xmf4x4World.m[1]));
}

CPlayer::CPlayer(CRailObject* rail) : CPlayer()
{
	m_railConnecter.SetRail(rail);
}

CPlayer::~CPlayer()
{

}

void CPlayer::Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent) 
{
	CGameObject::Animate(fTimeElapsed, pxmf4x4Parent);
	m_railConnecter.Move(m_xmf4x4Transform, fTimeElapsed);
	m_railConnecter.AddSpeed(10.0f * fTimeElapsed);
}

void CPlayer::UpdateTransform(XMFLOAT4X4A* pxmf4x4Parent) {
	CGameObject::UpdateTransform(pxmf4x4Parent);

	m_camera.GenerateViewMatrix(Vector3::TransformCoord(XMFLOAT3A(0, 5, -5), m_xmf4x4World), Vector3::Add(XMFLOAT3A(m_xmf4x4World.m[3]), XMFLOAT3A(0, 2, 0)), XMFLOAT3A(m_xmf4x4World.m[1]));
}

void CPlayer::LaneChange(int addLine)
{ 
	m_railConnecter.LaneChange(addLine); 
}
