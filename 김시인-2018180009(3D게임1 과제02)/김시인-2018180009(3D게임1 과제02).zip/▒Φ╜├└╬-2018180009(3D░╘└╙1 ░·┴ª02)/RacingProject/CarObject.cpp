#include "stdafx.h"
#include "CarObject.h"

CCarObject::CCarObject()
{
	uniform_real_distribution<float> urd(10.0f, 20.0f);
	m_railConnecter.SetSpeed(urd(dre));
}

CCarObject::CCarObject(CRailObject* rail) : CCarObject()
{
	m_railConnecter.SetRail(rail);
}

CCarObject::~CCarObject() {

}

void CCarObject::SetActive(bool active, int line, int point)
{
	if (m_active == active)
		return;

	m_active = active;

	if (m_active) {
		m_railConnecter.SetLine(line, 0.0f);
		m_railConnecter.SetPoint(point, 0);

		uniform_real_distribution<float> urd(10.0f, 20.0f);
		m_railConnecter.SetSpeed(urd(dre));
	}
}

void CCarObject::Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent, int playerPoint) 
{
	if (m_active) {
		CGameObject::Animate(fTimeElapsed, pxmf4x4Parent);
		m_railConnecter.Move(m_xmf4x4Transform, fTimeElapsed);

		int nLine = m_railConnecter.GetnLine();

		if (playerPoint - 30 < m_railConnecter.GetPoint() && m_railConnecter.GetPoint() < playerPoint - 5) {
			SetActive(false);
		}
	}
}

void CCarObject::Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera)
{
	if (m_active)
		CGameObject::Render(pd3dCommandList, pCamera);
}

void CCarObject::UpdateTransform(XMFLOAT4X4A* pxmf4x4Parent) 
{
	if (m_active)
		CGameObject::UpdateTransform(pxmf4x4Parent);
}
