#pragma once
#include "Mesh.h"
#include "Camera.h"

class CShader;

class CGameObject {
public:
	CGameObject();
	virtual ~CGameObject();

private:
	int m_nReferences = 0;

public:
	void AddRef() { m_nReferences++; }
	void Release() { if (--m_nReferences <= 0) delete this; }

public:
	BoundingOrientedBox			m_xmOOBB = BoundingOrientedBox();

protected:
	std::string m_frameName;

	CGameObject* m_pParent = NULL;
	CGameObject* m_pChild = NULL;
	CGameObject* m_pSibling = NULL;

	XMFLOAT4X4A m_xmf4x4Transform;
	XMFLOAT4X4A m_xmf4x4World;
	CMesh* m_pMesh = NULL;

	CShader* m_pShader = NULL;

public:
	void ReleaseUploadBuffers();
	virtual void SetMesh(CMesh* pMesh);
	virtual void SetShader(CShader* pShader);
	virtual void SetChild(CGameObject* pChild, bool bReferenceUpdate = false);

	virtual void Animate(float fTimeElapsed, XMFLOAT4X4A* pxmf4x4Parent);

	virtual void OnPrepareRender();
	virtual void Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera);

public:
	static CMeshLoadInfo* LoadMeshInfoFromFile(std::ifstream& file);
	static CGameObject* LoadFrameHierarchyFromFile(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList, std::ifstream& file);
	static CGameObject* LoadGeometryFromFile(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList, std::string fileName);

public:
	void Rotate(XMFLOAT3A* pxmf3Axis, float fAngle);
	virtual void UpdateTransform(XMFLOAT4X4A* pxmf4x4Parent);
	virtual void UpdateBoundingBox();
	bool CheckCollision(CGameObject& rhs);
	void SetPosition(float x, float y, float z);
	void SetPosition(XMFLOAT3A xmf3Position);
	XMFLOAT3A GetPosition(){ return(XMFLOAT3A(m_xmf4x4World._41, m_xmf4x4World._42, m_xmf4x4World._43)); }
	
};

///////////////////////////////////////////////////////////////////////////////
/// 
class CRotatingObject : public CGameObject {
public:
	CRotatingObject();
	virtual ~CRotatingObject();

private:
	XMFLOAT3A m_xmf3RotationAxis;
	float m_fRotationSpeed;

public:
	void SetRotationSpeed(float fRotationSpeed) { m_fRotationSpeed = fRotationSpeed; }
	void SetRotationAxis(XMFLOAT3A xmf3RotationAxis) {
		m_xmf3RotationAxis = xmf3RotationAxis;
	}
	virtual void Animate(float fTimeElapsed);
};