#pragma once
#include "GameObject.h"

///////////////////////////////////////////////////////////////////////////////
///

class CRailObject : public CGameObject {
public:
	CRailObject(int nLine, float lineWidth);
	virtual ~CRailObject();

private:
	// ������ �׸��� ���� ����
	CMesh** m_pMeshes;
	int m_nMeshes;

	// ������ ����� ���� ����
	float m_lineDistance = 1.0f;
	int m_nLine = 5;
	float m_lineWidth = 1.0f;

	std::vector<XMFLOAT3A>* m_points;
	std::vector<XMFLOAT3A>* m_velocities;

private:
	XMFLOAT3A CatmullRomSplinesPoint(float t, int startIndex, int endIndex, const std::vector<XMFLOAT3A>& points, const std::vector<XMFLOAT3A>& velocities);
	XMFLOAT3A CatmullRomSplinesVelocity(float t, int startIndex, int endIndex, const std::vector<XMFLOAT3A>& points, const std::vector<XMFLOAT3A>& velocities);

public:
	virtual void SetMesh(CMesh** pMeshes, int nMeshes);
	virtual void ReleaseUploadBuffers();
	virtual void Render(ID3D12GraphicsCommandList* pd3dCommandList, CCamera* pCamera);

	const std::vector<XMFLOAT3A>& GetPoints(int lineNumber) { return m_points[lineNumber]; }
	int GetnPoints() const { return (int)m_points[0].size(); }
	int GetnLine() const { return m_nLine; }
	float GetlineWidth() const { return m_lineWidth; }
	float GetDistanceBetweenTwoPoints(int aPoint, int bPoint, int line);
	XMFLOAT3A GetVelocity(int point, int line) { return m_velocities[line][point]; }
	XMFLOAT3A GetPoint(int point, int line) { return m_points[line][point]; }

};

///////////////////////////////////////////////////////////////////////////////
/// 
class CRailConnector {
public:
	CRailConnector();
	CRailConnector(CRailObject* myRail, bool reverse = false);
	virtual ~CRailConnector();

protected:
	CRailObject* m_myRail = NULL;
	bool m_reverse = false;

	int m_curLine = 0;	// ���� �޸��� �ִ� ����
	float m_lineOffset = 0.0f;
	int m_curPoint = 0;	// ���� ��� ��������
	float m_pointProgress = 0; // ���� ����Ʈ������ ���൵

	float m_speed = 10.0f;

public:
	void SetRail(CRailObject* rail) { m_myRail = rail; }
	void SetSpeed(float speed) { m_speed = max(speed, 0); }
	float GetSpeed() { return m_speed; }
	void AddSpeed(float speed) { m_speed = max(m_speed + speed, 0); }
	void SetLine(int line, float lineOffset) { m_curLine = line % m_myRail->GetnLine(); m_lineOffset = lineOffset; }
	void SetPoint(int index, float progress) { m_curPoint = index % m_myRail->GetnPoints(); m_pointProgress = progress; }

	int GetnLine() { return  m_myRail->GetnLine(); }
	int GetPoint() { return  m_curPoint; }

	void Move(XMFLOAT4X4A& xmf4x4World, float fElapsedTime);
	void LaneChange(int addLine);

};